-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Мар 16 2012 г., 17:58
-- Версия сервера: 5.1.61
-- Версия PHP: 5.3.5-1ubuntu7.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `kurs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nid` int(4) NOT NULL,
  `uid` int(3) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `title` varchar(128) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `nid`, `uid`, `uname`, `title`, `text`, `date`) VALUES
(20, 45, 38, 'Editor', ' sfdsg <<>', '  )[^><]+?(?=<|$) dfsfaf  ', '2012-03-14 14:25:56'),
(8, 40, 36, 'Trololo', 'France may...', 'France may withdraw from the Schengen area, if the EU does not fight with the invasion of illegal immigrants. ', '2012-03-13 12:59:20'),
(7, 40, 37, 'admin', 'President', 'President Nicolas Sarkozy at the pre-election rally. ', '2012-03-13 11:00:53'),
(6, 40, 36, 'Trololo', 'So once again...', 'So once again puts its national visa and customs regulations.', '2012-03-13 10:47:19'),
(9, 40, 44, 'testuser', 'This was...', 'This was announced by French President Nicolas Sarkozy at the pre-election rally.', '2012-03-13 13:14:06'),
(17, 45, 38, 'Editor', ' sfdsg <<>', ' sfdsg <<>', '2012-03-14 14:23:31'),
(18, 45, 38, 'Editor', '  dsad', '  dsad fdsf', '2012-03-14 14:24:14'),
(3, 40, 37, 'admin', 'На думку Саркоз...', 'На думку Саркоз Шенгенській зоні, до якої входять більшість країн західної і центральної Європи, необхідні інструменти для боротьби з кризою. Одна з її причин - нелегальна міграція. Саркозі закликав виключати з Шенгену ті країни, які пускатимуть до себе нелегалів. Якщо його аргументи не прийме решта країн, погрожує - вже за 12 місяців Франція вийде з угоди.', '2012-03-13 10:02:52'),
(27, 40, 37, 'admin', 'fdsf s...', 'fdsf s eeeggsgdgsgsgsg', '2012-03-16 09:30:00'),
(26, 40, 37, 'admin', 'd', 'd', '2012-03-16 09:29:55'),
(25, 46, 55, '123123', '', '', '2012-03-15 15:15:54'),
(23, 46, 55, '123123', '', '', '2012-03-15 15:15:49'),
(24, 46, 55, '123123', '', '', '2012-03-15 15:15:52'),
(21, 40, 55, '123123', 'rtyetyey', 'te ', '2012-03-15 15:12:35'),
(22, 46, 55, '123123', '', '', '2012-03-15 15:15:46'),
(28, 40, 37, 'admin', 'dsfsf', 'dsfsf', '2012-03-16 09:30:15');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nameuk` varchar(255) NOT NULL,
  `nameen` varchar(255) NOT NULL,
  `descriptionuk` text NOT NULL,
  `descriptionen` text NOT NULL,
  `textuk` text NOT NULL,
  `texten` text NOT NULL,
  `author` varchar(64) NOT NULL,
  `authorid` int(3) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `nameuk`, `nameen`, `descriptionuk`, `descriptionen`, `textuk`, `texten`, `author`, `authorid`, `date`) VALUES
(35, 'UK!!!Customers report receiving shipment notifications for new iPad', 'EN!!!Customers report receiving shipment notifications for new iPad', 'UK!!!Customers are reporting having received shipment notifications from Apple for preorders of the third-generation iPad, with delivery scheduled for March 16, the official release date.', 'EN!!!Customers are reporting having received shipment notifications from Apple for preorders of the third-generation iPad, with delivery scheduled for March 16, the official release date.', 'UK!!!<strong>Customers are reporting having received shipment notifications from Apple for preorders of the third-generation iPad, with delivery scheduled for March 16, the official release date.</strong><br/>\r\n<br/>\r\n<em>AppleInsider</em> reader Chris D''Aurora submitted a screenshot of an alleged shipment notification from Apple for a pre-order placed on Wednesday.<br/>\r\n<br/>\r\n"We''re happy to let you know that the items below are on their way to you," the notification read.<br/>\r\n<br/>\r\nThe device in question is a 16GB black iPad with Wi-Fi. The package was reportedly shipped through Federal Express and was listed as on track for delivery on March 16.<br/>\r\n<br/>\r\n<em>Engadget</em> <a href="http://www.engadget.com/2012/03/08/ipad-preorders-shipping-date/">reports</a> that several of its readers have received shipping references as well. Some them have also received UPS tracking numbers indicating the iPads are shipping from China.<br/>\r\n<br/>\r\nApple unveiled the third-generation iPad <a href="http://www.appleinsider.com/articles/12/03/07/apple_announces_new_ipad_hd_31_million_pixel_retina_display.html">on Wednesday</a> in San Francisco. The new tablet features a Retina Display, optional 4G LTE, a faster processor and a 5-megapixel camera. It will launch first in the U.S., Australia, Canada, France, Germany, Hong Kong, Japan, Puerto Rico, Singapore, Switzerland, UK and the US Virgin Islands on Friday, March 16.<br/>\r\n<br/>\r\n<div align="center"><img width="550" height="499" border="0" alt="" src="http://photos.appleinsider.com/ipad3ship-120309.png"/></div><br/>\r\n<br/>\r\nThe third-generation iPad launch could be significantly larger than last year''s iPad 2 launch, which landed in the U.S. first before going international two weeks later. U.S. pre-orders for the iPad appear to be going strong so far, as some models of the device are <a href="http://www.appleinsider.com/articles/12/03/08/estimated_shipping_dates_for_att_4g_lte_ipads_begin_slipping_to_march_19.html">no longer available</a> for launch day delivery. The white 16GB and 64GB Wi-Fi + 4G AT&T iPad models are currently listed as shipping by March 19.<br/>\r\n<br/>\r\nWall Street''s <a href="http://www.appleinsider.com/articles/12/03/08/wall_street_expects_new_ipad_to_continue_dominating_tablet_market.html">reaction</a> to the new iPad has been positive overall. Several analysts view the accelerated international rollout as a potential sign of an upside to iPad shipments this quarter.<br/>\r\n<br/>\r\n<div align="center"><img width="550" height="370" border="0" alt="" src="http://photos.appleinsider.com/ipadnew120307-2.png"/></div><p/>', 'EN!!!<strong>Customers are reporting having received shipment notifications from Apple for preorders of the third-generation iPad, with delivery scheduled for March 16, the official release date.</strong><br/>\r\n<br/>\r\n<em>AppleInsider</em> reader Chris D''Aurora submitted a screenshot of an alleged shipment notification from Apple for a pre-order placed on Wednesday.<br/>\r\n<br/>\r\n"We''re happy to let you know that the items below are on their way to you," the notification read.<br/>\r\n<br/>\r\nThe device in question is a 16GB black iPad with Wi-Fi. The package was reportedly shipped through Federal Express and was listed as on track for delivery on March 16.<br/>\r\n<br/>\r\n<em>Engadget</em> <a href="http://www.engadget.com/2012/03/08/ipad-preorders-shipping-date/">reports</a> that several of its readers have received shipping references as well. Some them have also received UPS tracking numbers indicating the iPads are shipping from China.<br/>\r\n<br/>\r\nApple unveiled the third-generation iPad <a href="http://www.appleinsider.com/articles/12/03/07/apple_announces_new_ipad_hd_31_million_pixel_retina_display.html">on Wednesday</a> in San Francisco. The new tablet features a Retina Display, optional 4G LTE, a faster processor and a 5-megapixel camera. It will launch first in the U.S., Australia, Canada, France, Germany, Hong Kong, Japan, Puerto Rico, Singapore, Switzerland, UK and the US Virgin Islands on Friday, March 16.<br/>\r\n<br/>\r\n<div align="center"><img width="550" height="499" border="0" alt="" src="http://photos.appleinsider.com/ipad3ship-120309.png"/></div><br/>\r\n<br/>\r\nThe third-generation iPad launch could be significantly larger than last year''s iPad 2 launch, which landed in the U.S. first before going international two weeks later. U.S. pre-orders for the iPad appear to be going strong so far, as some models of the device are <a href="http://www.appleinsider.com/articles/12/03/08/estimated_shipping_dates_for_att_4g_lte_ipads_begin_slipping_to_march_19.html">no longer available</a> for launch day delivery. The white 16GB and 64GB Wi-Fi + 4G AT&T iPad models are currently listed as shipping by March 19.<br/>\r\n<br/>\r\nWall Street''s <a href="http://www.appleinsider.com/articles/12/03/08/wall_street_expects_new_ipad_to_continue_dominating_tablet_market.html">reaction</a> to the new iPad has been positive overall. Several analysts view the accelerated international rollout as a potential sign of an upside to iPad shipments this quarter.<br/>\r\n<br/>\r\n<div align="center"><img width="550" height="370" border="0" alt="" src="http://photos.appleinsider.com/ipadnew120307-2.png"/></div><p/>', 'admin', 37, '2012-03-09'),
(34, 'Mitt Romney''s next big challenge: Winning over the South', 'EN!Mitt Romney''s next big challenge: Winning over the South', 'JACKSON, Miss. -- Mitt Romney faces a tough sell in the Deep South.\r\n\r\nWith primaries in Mississippi and Alabama coming up Tuesday, there''s concern...', 'EN!JACKSON, Miss. -- Mitt Romney faces a tough sell in the Deep South.\r\n\r\nWith primaries in Mississippi and Alabama coming up Tuesday, there''s concern...', 'JACKSON, Miss. -- Mitt Romney faces a tough sell in the Deep South.\r\n\r\nWith primaries in Mississippi and Alabama coming up Tuesday, there''s concern that he''s too slick, not really a conservative. In a region where the vote of evangelical Christians is important, some are skeptical about his Mormon faith.\r\n\r\nBut if Romney wins the Republican nomination and it''s between him and President Barack Obama, the former Massachusetts governor and Michigan native may be just good enough for some Southerners.\r\n\r\n"If push comes to shove ... I''ll go in the voting booth like this and vote for him," Mississippi retiree David Wilke said, holding his nose.\r\n\r\nFormer House Speaker Newt Gingrich, who represented Georgia for 20 years and now lives in Virginia, needs to win every state from South Carolina to Texas to get to the convention this summer, spokesman R.C. Hammond said. The staff of former U.S. Sen. Rick Santorum of Pennsylvania said he will be aggressive in states where Gingrich expects to perform well.\r\n\r\nGingrich scored an early primary victory in South Carolina and won this week in Georgia. Romney added a Virginia win this week -- Gingrich and Santorum weren''t on the ballot -- to his Jan. 31 win in Florida. Santorum won Tennessee.\r\n\r\nAfter Mississippi and Alabama next week, Louisiana will vote March 24; North Carolina and West Virginia vote May 8; Arkansas on May 22, and Texas on May 29.\r\n\r\nRomney acknowledges an uphill battle. In an interview Thursday with a Birmingham, Ala., radio station, he said the Deep South contests would be "a bit of an away game" for him.\r\n\r\nStill, Romney is supported by top Republicans in many Southern states, and he''ll speak in Birmingham today.\r\n\r\nFormer Alabama Gov. Bob Riley has endorsed him. "Mitt Romney is the only candidate with the leadership and business experience to take our country through this difficult economic situation," Riley said.\r\n\r\nIn Mississippi, most statewide elected officials endorsed Romney, and both of the state''s Republican National Committee members support him.\r\n\r\nMeanwhile, former U.S. Sen. Rick Santorum of Pennsylvania appealed Thursday for votes in Alabama''s primary, calling the state the "heart of conservatism" and casting himself as the best fit for its voters.\r\n\r\nGingrich was keeping up a rigorous schedule Thursday and today, with events planned from the far northwest corner of Mississippi to Gulfport on the gulf coast, before plowing back into Alabama on Saturday.\r\n', 'EN!JACKSON, Miss. -- Mitt Romney faces a tough sell in the Deep South.\r\n\r\nWith primaries in Mississippi and Alabama coming up Tuesday, there''s concern that he''s too slick, not really a conservative. In a region where the vote of evangelical Christians is important, some are skeptical about his Mormon faith.\r\n\r\nBut if Romney wins the Republican nomination and it''s between him and President Barack Obama, the former Massachusetts governor and Michigan native may be just good enough for some Southerners.\r\n\r\n"If push comes to shove ... I''ll go in the voting booth like this and vote for him," Mississippi retiree David Wilke said, holding his nose.\r\n\r\nFormer House Speaker Newt Gingrich, who represented Georgia for 20 years and now lives in Virginia, needs to win every state from South Carolina to Texas to get to the convention this summer, spokesman R.C. Hammond said. The staff of former U.S. Sen. Rick Santorum of Pennsylvania said he will be aggressive in states where Gingrich expects to perform well.\r\n\r\nGingrich scored an early primary victory in South Carolina and won this week in Georgia. Romney added a Virginia win this week -- Gingrich and Santorum weren''t on the ballot -- to his Jan. 31 win in Florida. Santorum won Tennessee.\r\n\r\nAfter Mississippi and Alabama next week, Louisiana will vote March 24; North Carolina and West Virginia vote May 8; Arkansas on May 22, and Texas on May 29.\r\n\r\nRomney acknowledges an uphill battle. In an interview Thursday with a Birmingham, Ala., radio station, he said the Deep South contests would be "a bit of an away game" for him.\r\n\r\nStill, Romney is supported by top Republicans in many Southern states, and he''ll speak in Birmingham today.\r\n\r\nFormer Alabama Gov. Bob Riley has endorsed him. "Mitt Romney is the only candidate with the leadership and business experience to take our country through this difficult economic situation," Riley said.\r\n\r\nIn Mississippi, most statewide elected officials endorsed Romney, and both of the state''s Republican National Committee members support him.\r\n\r\nMeanwhile, former U.S. Sen. Rick Santorum of Pennsylvania appealed Thursday for votes in Alabama''s primary, calling the state the "heart of conservatism" and casting himself as the best fit for its voters.\r\n\r\nGingrich was keeping up a rigorous schedule Thursday and today, with events planned from the far northwest corner of Mississippi to Gulfport on the gulf coast, before plowing back into Alabama on Saturday.\r\n', 'Editor', 38, '2012-03-09'),
(38, 'Венесуэльская армия по ошибке вторглась в Колумбию', 'EN!Венесуэльская армия по ошибке вторглась в Колумбию', '<p class="b-article__paragraph">Подразделение национальной гвардии Венесуэлы вторглось на территорию соседней Колумбии в департаменте...', 'EN!!<p class="b-article__paragraph">Подразделение национальной гвардии Венесуэлы вторглось на территорию соседней Колумбии в департаменте...', '<p class="b-article__paragraph">Подразделение национальной гвардии Венесуэлы вторглось на территорию соседней Колумбии в департаменте Норте-де-Сантандер на севере страны.</p><p class="b-article__paragraph">«Они преследовали контрабандистов бензина, которые переправляют топливо между Венесуэлой и Колумбией, и в запале погони пересекли границу», — пояснила министр иностранных дел Колумбии Мария Анхела Ольгин, которую цитирует издание Colombia Reports.</p><p class="b-article__paragraph">Венесуэльские военные встретились с колумбийскими войсками и только тогда поняли, что находятся на территории соседнего государства. Глава МИД подчеркнула, что «в результате инцидента не было ни убитых, ни раненых», хотя имели место несколько выстрелов: венесуэльские гвардейцы стреляли в сторону уходивших от преследования контрабандистов.</p>', 'EN!!<p class="b-article__paragraph">Подразделение национальной гвардии Венесуэлы вторглось на территорию соседней Колумбии в департаменте Норте-де-Сантандер на севере страны.</p><p class="b-article__paragraph">«Они преследовали контрабандистов бензина, которые переправляют топливо между Венесуэлой и Колумбией, и в запале погони пересекли границу», — пояснила министр иностранных дел Колумбии Мария Анхела Ольгин, которую цитирует издание Colombia Reports.</p><p class="b-article__paragraph">Венесуэльские военные встретились с колумбийскими войсками и только тогда поняли, что находятся на территории соседнего государства. Глава МИД подчеркнула, что «в результате инцидента не было ни убитых, ни раненых», хотя имели место несколько выстрелов: венесуэльские гвардейцы стреляли в сторону уходивших от преследования контрабандистов.</p>', 'admin', 37, '2012-03-09'),
(39, 'Власти Калифорнии заставили Coca-Cola и Pepsi изменить рецепты', 'EN!Власти Калифорнии заставили Coca-Cola и Pepsi изменить рецепты', '<p class="b-article__paragraph">Компании Coca-Cola и PepsiCo изменят рецепты своих напитков, чтобы избежать необходимости предупреждать покупателей о...', '<p class="b-article__paragraph">Компании Coca-Cola и PepsiCo изменят рецепты своих напитков, чтобы избежать необходимости предупреждать покупателей о...', '<p class="b-article__paragraph">Компании Coca-Cola и PepsiCo изменят рецепты своих напитков, чтобы избежать необходимости предупреждать покупателей о содержании канцерогенов в продуктах, сообщает Associated Press.</p><p class="b-article__paragraph">Изменения связаны с новым законом штата Калифорнии, который относит 4-метилимидазол, используемый в карамельном красителе кока-колы и пепси-колы, к числу канцерогенов. Coca-Cola обратится к своим поставщикам карамели с просьбой изменить процесс ее приготовления, чтобы в результате образовывалось меньше этого вещества. При этом компания обращает внимание на то, что, по ее мнению, риска для здоровья, который оправдывал бы изменения рецепта, кола не несет.</p><p class="b-article__paragraph">Высокий уровень содержания 4-метилимидазола в кока-коле, пепси-коле и диетических версиях этих напитков обнаружил Центр по использованию достижений науки в интересах общества, с февраля 2011 года пытающийся добиться запрета аммиачно-сульфитных карамельных красителей.</p><p class="b-article__paragraph">«Cola и Pepsi с согласия Управления по контролю качества продуктов и лекарств без нужды подвергают миллионы американцев воздействию химиката, который вызывает рак. Этот краситель — совершенно косметическое вещество, ничего не добавляющее вкусу напитка. Если компании могут производить коричневый пищевой краситель без канцерогенов, они должны делать это», — говорится в заявлении Центра. В качестве примера Центр приводит напитки «Доктор Пеппер», в которых содержится в разы меньше 4-метилимидазола, чем в продукции Coca-Cola и PepsiCo.</p><p class="b-article__paragraph">В ответ на это Американская ассоциация производителей напитков заявила о том, что Центр по использованию достижений науки пытается «запугать» производителей колы. «На самом деле наука просто не доказывает того, что 4-метилимидазол в еде или напитках представляет угрозу здоровью людей», — говорится в заявлении ассоциации.</p><p class="b-article__paragraph">Ассоциация также отмечает, что Калифорния включила 4-метилимидазол в число канцерогенов, не опираясь на исследования, доказывающие, что это вещество вызывает рак у людей.</p><p class="b-article__paragraph">«Человек должен выпивать по 2900 банок колы каждый день в течение 70 лет, чтобы достичь минимальной дозы, которая вызвала опухоль у крыс в том исследовании, на которое опирались власти Калифорнии при своем запрете», — утверждает ассоциация. О том же заявило и Управление по контролю качества продуктов и лекарств, сообщает Bloomberg.</p><p class="b-article__paragraph">Coca-Cola и PepsiCo вместе занимают почти 90 процентов рынка газированных напитков в США. По заверениям представителей компаний, изменения рецепта не повлияют на вкус газировки.</p>', '<p class="b-article__paragraph">Компании Coca-Cola и PepsiCo изменят рецепты своих напитков, чтобы избежать необходимости предупреждать покупателей о содержании канцерогенов в продуктах, сообщает Associated Press.</p><p class="b-article__paragraph">Изменения связаны с новым законом штата Калифорнии, который относит 4-метилимидазол, используемый в карамельном красителе кока-колы и пепси-колы, к числу канцерогенов. Coca-Cola обратится к своим поставщикам карамели с просьбой изменить процесс ее приготовления, чтобы в результате образовывалось меньше этого вещества. При этом компания обращает внимание на то, что, по ее мнению, риска для здоровья, который оправдывал бы изменения рецепта, кола не несет.</p><p class="b-article__paragraph">Высокий уровень содержания 4-метилимидазола в кока-коле, пепси-коле и диетических версиях этих напитков обнаружил Центр по использованию достижений науки в интересах общества, с февраля 2011 года пытающийся добиться запрета аммиачно-сульфитных карамельных красителей.</p><p class="b-article__paragraph">«Cola и Pepsi с согласия Управления по контролю качества продуктов и лекарств без нужды подвергают миллионы американцев воздействию химиката, который вызывает рак. Этот краситель — совершенно косметическое вещество, ничего не добавляющее вкусу напитка. Если компании могут производить коричневый пищевой краситель без канцерогенов, они должны делать это», — говорится в заявлении Центра. В качестве примера Центр приводит напитки «Доктор Пеппер», в которых содержится в разы меньше 4-метилимидазола, чем в продукции Coca-Cola и PepsiCo.</p><p class="b-article__paragraph">В ответ на это Американская ассоциация производителей напитков заявила о том, что Центр по использованию достижений науки пытается «запугать» производителей колы. «На самом деле наука просто не доказывает того, что 4-метилимидазол в еде или напитках представляет угрозу здоровью людей», — говорится в заявлении ассоциации.</p><p class="b-article__paragraph">Ассоциация также отмечает, что Калифорния включила 4-метилимидазол в число канцерогенов, не опираясь на исследования, доказывающие, что это вещество вызывает рак у людей.</p><p class="b-article__paragraph">«Человек должен выпивать по 2900 банок колы каждый день в течение 70 лет, чтобы достичь минимальной дозы, которая вызвала опухоль у крыс в том исследовании, на которое опирались власти Калифорнии при своем запрете», — утверждает ассоциация. О том же заявило и Управление по контролю качества продуктов и лекарств, сообщает Bloomberg.</p><p class="b-article__paragraph">Coca-Cola и PepsiCo вместе занимают почти 90 процентов рынка газированных напитков в США. По заверениям представителей компаний, изменения рецепта не повлияют на вкус газировки.</p>', 'Editor', 38, '2012-03-09'),
(40, 'Саркозі бореться з мігрантами', 'Sarkozy struggles with migrants', 'Франція може вийти з Шенгенської зони, якщо ЄС не боротиметься з навалою нелегальних мігрантів.\r\n\r\nПро це заявив президент Франції Ніколя Саркозі на...', 'France may withdraw from the Schengen area, if the EU does not fight with the invasion of illegal immigrants.\r\n\r\nThis was announced by French...', 'Франція може вийти з Шенгенської зони, якщо ЄС не боротиметься з навалою нелегальних мігрантів.\r\n\r\nПро це заявив президент Франції Ніколя Саркозі на передвиборчому мітингу. Підтримати чинного президента, який балотується на другий термін, зібралося 50 тисяч людей. На думку Саркозі Шенгенській зоні, до якої входять більшість країн західної і центральної Європи, необхідні інструменти для боротьби з кризою. Одна з її причин - нелегальна міграція. Саркозі закликав виключати з Шенгену ті країни, які пускатимуть до себе нелегалів. Якщо його аргументи не прийме решта країн, погрожує - вже за 12 місяців Франція вийде з угоди. А отже знову введе свої національні візи та митні правила.', 'France may withdraw from the Schengen area, if the EU does not fight with the invasion of illegal immigrants.\r\n\r\nThis was announced by French President Nicolas Sarkozy at the pre-election rally. To support the current president who is running for a second term, gathered 50 000 people. According to Sarkozy, the Schengen area, which includes most of western and central Europe, the necessary tools to combat the crisis. One of its causes - illegal immigration. Sarkozy urged the exclusion of those Schengen countries that puskatymut themselves illegal. If his arguments do not take the rest of the country threatens - already 12 months France will emerge from the agreement. So once again puts its national visa and customs regulations.', 'admin', 37, '2012-03-12');

-- --------------------------------------------------------

--
-- Структура таблицы `page_title`
--

CREATE TABLE IF NOT EXISTS `page_title` (
  `file` varchar(64) NOT NULL,
  `uk` varchar(255) NOT NULL,
  `en` varchar(255) NOT NULL,
  `arrayuk` text NOT NULL,
  `arrayen` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `page_title`
--

INSERT INTO `page_title` (`file`, `uk`, `en`, `arrayuk`, `arrayen`) VALUES
('add_news.php', 'Створення новини', 'Add news', 'a:9:{s:7:"titleen";s:31:"Назва англійська";s:13:"descriptionen";s:46:"Короткий опис англійскою";s:6:"texten";s:33:"Текст англійською";s:7:"titleuk";s:33:"Назва українською";s:13:"descriptionuk";s:48:"Короткий опис українською";s:6:"textuk";s:33:"Текст українською";s:6:"author";s:10:"Автор";s:9:"date_news";s:21:"Дата новини";s:6:"button";s:16:"Зберегти";}', 'a:9:{s:7:"titleen";s:13:"Title english";s:13:"descriptionen";s:19:"Description english";s:6:"texten";s:12:"Text english";s:7:"titleuk";s:15:"Title ukrainian";s:13:"descriptionuk";s:21:"Description ukrainian";s:6:"textuk";s:14:"Text ukrainian";s:6:"author";s:6:"Author";s:9:"date_news";s:9:"Date news";s:6:"button";s:4:"Save";}'),
('index.php', 'Головна', 'Main', '', ''),
('registration.php', 'Реестрація', 'Registration', 'a:9:{s:5:"login";s:10:"Логін";s:8:"password";s:12:"Пароль";s:9:"password2";s:35:"Підтвердіть пароль";s:5:"email";s:31:"Електронна пошта";s:4:"name";s:11:"Ім&#39;я";s:5:"lname";s:16:"Прізвище";s:6:"avatar";s:12:"Аватар";s:8:"birthday";s:29:"Дата народження";s:6:"button";s:30:"Зарееструватись";}', 'a:9:{s:5:"login";s:5:"Login";s:8:"password";s:8:"Password";s:9:"password2";s:16:"Confirm Password";s:5:"email";s:5:"email";s:4:"name";s:4:"Name";s:5:"lname";s:9:"Last name";s:6:"avatar";s:6:"Avatar";s:8:"birthday";s:24:"Enter Your Date of Birth";s:6:"button";s:21:"Complete Registration";}'),
('delete_news.php', 'Видалення новини', 'Remove news', 'a:1:{s:6:"button";s:16:"Видалити";}', 'a:1:{s:6:"button";s:6:"Remove";}'),
('edit_user.php', 'Редагування користувача', 'Edit user', '', ''),
('login.php', 'Авторизація', 'Authorization', 'a:3:{s:6:"banned";s:44:"ваш аккаунт заблоковано";s:9:"incorrect";s:48:"Не вірний логін або пароль";s:9:"not_found";s:45:"Логін або email не знайдені";}', 'a:3:{s:6:"banned";s:14:"you are banned";s:9:"incorrect";s:61:"Your email, login or password is incorrect, please try again.";s:9:"not_found";s:29:"This login or email not found";}'),
('profile.php', 'Редагування профілю', 'Edit profile', 'a:8:{s:8:"password";s:12:"Пароль";s:9:"password2";s:35:"Підтвердіть пароль";s:5:"email";s:31:"Електронна пошта";s:4:"name";s:7:"Ім''я";s:9:"last_name";s:16:"Прізвище";s:6:"avatar";s:12:"Автара";s:8:"birthday";s:44:"Вкажіть дату народження";s:6:"button";s:16:"Зберегти";}', 'a:8:{s:8:"password";s:8:"Password";s:9:"password2";s:16:"Confirm Password";s:5:"email";s:5:"email";s:4:"name";s:4:"Name";s:9:"last_name";s:9:"Last name";s:6:"avatar";s:6:"Avatar";s:8:"birthday";s:24:"Enter Your Date of Birth";s:6:"button";s:4:"Save";}'),
('update.php', 'Редагування новин', 'Edit news', '', ''),
('update_news.php', 'Редагування новини', 'Edit news', 'a:9:{s:7:"titleen";s:31:"Назва англійська";s:13:"descriptionen";s:46:"Короткий опис англійскою";s:6:"texten";s:33:"Текст англійською";s:7:"titleuk";s:33:"Назва українською";s:13:"descriptionuk";s:48:"Короткий опис українською";s:6:"textuk";s:33:"Текст українською";s:6:"author";s:10:"Автор";s:9:"date_news";s:21:"Дата новини";s:6:"button";s:16:"Зберегти";}', 'a:9:{s:7:"titleen";s:13:"Title english";s:13:"descriptionen";s:19:"Description english";s:6:"texten";s:12:"Text english";s:7:"titleuk";s:15:"Title ukrainian";s:13:"descriptionuk";s:21:"Description ukrainian";s:6:"textuk";s:14:"Text ukrainian";s:6:"author";s:6:"Author";s:9:"date_news";s:9:"Date news";s:6:"button";s:4:"Save";}'),
('update_profile.php', 'Редагування профілю', 'Edit profile', 'a:5:{s:7:"no_mail";s:46:"Вкажіть електронну пошту";s:10:"pass_error";s:40:"Паролі не співпадають";s:10:"mail_error";s:47:"Не вірна електронна пошта";s:10:"mail_exist";s:50:"пошта вже використовується";s:8:"complete";s:38:"Дані успішно змінено";}', 'a:5:{s:7:"no_mail";s:18:"please enter email";s:10:"pass_error";s:34:"The entered passwords do not match";s:10:"mail_error";s:10:"mail error";s:10:"mail_exist";s:19:"email already exist";s:8:"complete";s:6:"Edited";}'),
('users.php', 'Список користувачів', 'User list', 'a:2:{s:4:"edit";s:20:"Редагувати";s:6:"remove";s:16:"Видалити";}', 'a:2:{s:4:"edit";s:4:"Edit";s:6:"remove";s:6:"Remove";}'),
('view_profile.php', 'Профіль', 'Profile', 'a:4:{s:7:"created";s:28:"Зареестрований";s:6:"logged";s:22:"Був на сайті";s:12:"edit_profile";s:35:"Редагувати профіль";s:14:"remove_profile";s:31:"Видалити профіль";}', 'a:4:{s:7:"created";s:7:"Created";s:6:"logged";s:11:"Last log in";s:12:"edit_profile";s:12:"Edit profile";s:14:"remove_profile";s:14:"Remove profile";}'),
('sidebarR.php', '', '', 'a:12:{s:5:"login";s:10:"логін";s:8:"password";s:12:"пароль";s:6:"button";s:12:"Ввійти";s:12:"registration";s:20:"Реестрація";s:8:"greeting";s:12:"Привіт";s:8:"add_news";s:21:"Нова новина";s:7:"profile";s:14:"Профіль";s:9:"edit_news";s:33:"Редагувати новини";s:11:"remove_news";s:29:"Видалення новин";s:9:"user_list";s:22:"Користувачі";s:9:"edit_text";s:37:"Редагування текстів";s:6:"logout";s:10:"Вийти";}', 'a:12:{s:5:"login";s:5:"login";s:8:"password";s:8:"password";s:6:"button";s:6:"Log in";s:12:"registration";s:12:"Registration";s:8:"greeting";s:5:"Hello";s:8:"add_news";s:8:"Add news";s:7:"profile";s:7:"Profile";s:9:"edit_news";s:9:"Edit news";s:11:"remove_news";s:11:"Remove news";s:9:"user_list";s:9:"User list";s:9:"edit_text";s:9:"Edit text";s:6:"logout";s:6:"Logout";}'),
('sidebarL.php', '', '', 'a:2:{s:4:"main";s:14:"Головна";s:12:"registration";s:20:"Реестрація";}', 'a:2:{s:4:"main";s:4:"Main";s:12:"registration";s:12:"Registration";}'),
('content.php', '', '', 'a:3:{s:6:"author";s:10:"Автор";s:9:"date_news";s:21:"Дата новини";s:9:"read_more";s:24:"Читати далі...";}', 'a:3:{s:6:"author";s:6:"Author";s:9:"date_news";s:9:"Date news";s:9:"read_more";s:9:"Read more";}'),
('read.php', '', '', 'a:12:{s:6:"rating";s:26:"Cередня оцінка";s:12:"count_rating";s:33:"кількість голосів";s:7:"norated";s:66:"За цей метріал ще ніхто не голосував";s:13:"rating_choice";s:30:"Виберіть оцінку ";s:13:"button_rating";s:14:"Оцінити";s:9:"your_mark";s:41:"Ваша оцінка матеріалу:";s:17:"button_del_rating";s:29:"Видалити оцінку";s:6:"remove";s:16:"Видалити";s:4:"edit";s:20:"Редагувати";s:5:"title";s:27:"Тема коментаря";s:4:"text";s:29:"Текст коментаря";s:6:"button";s:22:"Коментувати";}', 'a:12:{s:6:"rating";s:6:"Rating";s:12:"count_rating";s:5:"rated";s:7:"norated";s:8:"no rated";s:13:"rating_choice";s:7:"Choice ";s:13:"button_rating";s:2:"ok";s:9:"your_mark";s:9:"your mark";s:17:"button_del_rating";s:6:"Remove";s:6:"remove";s:6:"Remove";s:4:"edit";s:4:"Edit";s:5:"title";s:15:"Subject comment";s:4:"text";s:12:"Text comment";s:6:"button";s:3:"Add";}'),
('edit_text.php', 'Редагування текстів', 'Edit text', 'a:2:{s:7:"titleen";s:50:"Назва сторінки англійською";s:7:"titleuk";s:50:"Назва сторінки українською";}', 'a:2:{s:7:"titleen";s:13:"Title english";s:7:"titleuk";s:15:"Title ukrainian";}'),
('add_rating.php', 'Рейтинг', 'Rating', 'a:1:{s:5:"thank";s:41:"Дякуємо за вашу оцінку";}', 'a:1:{s:5:"thank";s:20:"Thank you for rating";}'),
('formdata.php', 'Реестрація', 'Registration', 'a:8:{s:11:"login_error";s:81:"Логін повинен складатись з латинських літер";s:8:"no_login";s:25:"Вкажіть логін";s:7:"no_mail";s:46:"Вкажіть електронну пошту";s:7:"no_pass";s:27:"Введіть пароль";s:10:"pass_error";s:40:"Паролі не співпадають";s:10:"mail_error";s:47:"Не вірна електронна пошта";s:11:"login_exist";s:50:"Логін вже використовується";s:10:"mail_exist";s:50:"Пошта вже використовується";}', 'a:8:{s:11:"login_error";s:15:"incorrect login";s:8:"no_login";s:18:"please enter login";s:7:"no_mail";s:18:"please enter email";s:7:"no_pass";s:21:"please enter password";s:10:"pass_error";s:34:"The entered passwords do not match";s:10:"mail_error";s:10:"mail error";s:11:"login_exist";s:19:"login already exist";s:10:"mail_exist";s:19:"email already exist";}');

-- --------------------------------------------------------

--
-- Структура таблицы `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(3) NOT NULL,
  `nid` int(4) NOT NULL,
  `rating` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Дамп данных таблицы `rating`
--

INSERT INTO `rating` (`id`, `uid`, `nid`, `rating`) VALUES
(14, 36, 40, 4),
(17, 45, 40, 5),
(4, 35, 40, 5),
(16, 44, 40, 4),
(18, 55, 40, 4),
(19, 55, 46, 5),
(33, 37, 40, 5),
(25, 37, 35, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `rid` int(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`rid`, `name`) VALUES
(1, 'administrator'),
(2, 'anonymous'),
(3, 'authorized'),
(4, 'editor'),
(5, 'blocked');

-- --------------------------------------------------------

--
-- Структура таблицы `roles_permission`
--

CREATE TABLE IF NOT EXISTS `roles_permission` (
  `rid` int(1) NOT NULL,
  `permission` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `roles_permission`
--

INSERT INTO `roles_permission` (`rid`, `permission`) VALUES
(1, 'add news'),
(1, 'edit news'),
(1, 'remove news'),
(4, 'add news'),
(4, 'edit news'),
(4, 'remove news'),
(1, 'admin permission'),
(3, 'add comment'),
(4, 'add comment'),
(3, 'rating'),
(4, 'rating');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `yearB` int(4) NOT NULL,
  `monthB` int(2) NOT NULL,
  `dayB` int(2) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `rid` int(1) NOT NULL,
  `created` date NOT NULL,
  `logged` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `name`, `lastname`, `yearB`, `monthB`, `dayB`, `avatar`, `rid`, `created`, `logged`) VALUES
(36, 'qaz', '$1$uLm/yjrx$0Mnr2SqrJ7so.W3hbWf2C/', 'qaz@qaz.qaz', 'Trololo', '', 1991, 10, 28, '', 5, '2012-03-08', '2012-03-13 00:00:00'),
(38, 'editor', '$1$RZ7z7Gqq$zi3.K4d8/d06JhI9vTcki/', 'editor@kurs.loc', 'Editor', 'Editor', 1979, 5, 21, 'upload/20120316152217logo.png', 4, '2012-03-08', '2012-03-16 15:21:42'),
(37, 'admin', '$1$Qw6m0wLy$E/hGhEGAkprT6JFmX9Wxh0', 'admin@kurs.loc', 'admin', 'admin', 1986, 12, 26, 'upload/20120316152123logo.png', 1, '2012-03-08', '2012-03-16 17:40:00'),
(44, 'testuser', '$1$bl22pO8t$bYHuyEtK5dezsLVqLh3gP/', 'testuser@kurs.loc', 'testuser', '', 1992, 1, 1, '', 3, '2012-03-13', '2012-03-13 00:00:00'),
(45, 'тібеж', '$1$DtcOLZGG$buR31WnoASaX1nZFj1Uq9/', 'фів', 'тібеж', '12', 1994, 1, 1, 'upload/000087.jpg', 3, '2012-03-13', '2012-03-13 00:00:00'),
(57, 'gr', '$1$zRabRlXb$yon4ypJ8HviZZn/nC4ESe0', 'rere', 'rere', '', 1994, 1, 1, '', 3, '2012-03-15', '2012-03-15 16:19:38'),
(56, '12', '$1$vraklaF1$QQD/aisrqCWl88AZjwcMD/', 'sdf@asd.rrr12', '12', '', 1994, 1, 1, '', 5, '2012-03-15', '2012-03-15 15:20:43'),
(55, '123123', '$1$WfhY0E9K$/qej9Qt2z11SiUO9s6C0V.', 'sdf@asd.rrr', '123123', '123', 1940, 1, 1, 'upload/20120315151157000087.jpg', 5, '2012-03-15', '2012-03-15 15:11:29'),
(54, 'qqq', '$1$EfYoX0iC$Au8aOI8FqiJGNwZqMtT.U0', '212@we.re', 'qqqqqqqqq', '', 1993, 1, 1, 'upload/20120314133618logo.png', 3, '2012-03-14', '2012-03-14 13:32:20'),
(58, 'wer', '$1$qcKW/shi$04hzt3fWp7hmbg1ibbW.M/', 'wer@wer.wer', 'wer', '', 1994, 1, 1, '', 3, '2012-03-16', '2012-03-16 15:25:25');
